   ______ _                          _      _     _             _            
  |  ____| |                        | |    | |   | |           | |           
  | |__  | | _____   _____ _ __   __| | ___| |__ | | ___   __ _| |_ ___ _ __ 
  |  __| | |/ _ \ \ / / _ \ '_ \ / _\` |/ _ \ '_ \| |/ _ \ / _\` | __/ _ \ 
  | |____| |  __/\ V /  __/ | | | (_| |  __/ |_) | | (_) | (_| | ||  __/ |   
  |______|_|\___| \_/ \___|_| |_|\__,_|\___|_.__/|_|\___/ \__,_|\__\___|_|   
      | |   (_) | | |                  | (_) | (_)                           
   ___| |__  _| |_| |_ _   _    ___  __| |_| |_ _  ___  _ __                 
  / __| '_ \| | __| __| | | |  / _ \/ _\` | | __| |/ _ \| '_ \ tm            
  \__ \ | | | | |_| |_| |_| | |  __/ (_| | | |_| | (_) | | | |               
  |___/_| |_|_|\__|\__|\__, |  \___|\__,_|_|\__|_|\___/|_| |_|               
                        __/ |                                                
                       |___/                                                 
   _                                     _ _        _                            
  | |                                   | (_)      (_)                           
  | |__  _   _   ___ _ __   ___  ___  __| |_  ___   _    __ _ _   _  ___ ___ ___ 
  | '_ \| | | | / __| '_ \ / _ \/ _ \/ _\` | |/ _ \ | |  / _\` | | | |/ _ / __/ __|
  | |_) | |_| | \__ | |_) |  __|  __| (_| | |  __/ | | | (_| | |_| |  __\__ \__ \
  |_.__/ \__, | |___| .__/ \___|\___|\__,_|_|\___| |_|  \__, |\__,_|\___|___|___/
          __/ |     | |                                  __/ |                   
         |___/      |_|                                 |___/                    


Elevendebloater 0.3

A pretty not-so-good Windows 11 debloater I made because I have no life.
Unless you modify the script, it will delete all of these.
#############################################################
 windowscommunicationsapps_8wekyb3d8bbwe
 OneDrive
 MicrosoftTeams_8wekyb3d8bbwe
 ZuneVideo_8wekyb3d8bbwe
 ZuneMusic_8wekyb3d8bbwe
 549981C3F5F10_8wekyb3d8bbwe
 BingNews_8wekyb3d8bbwe
 BingWeather_8wekyb3d8bbwe
 GamingApp_8wekyb3d8bbwe
 GetHelp_8wekyb3d8bbwe
 Getstarted_8wekyb3d8bbwe
 MicrosoftOfficeHub_8wekyb3d8bbwe
 MicrosoftSolitaireCollection_8wekyb3d8bbwe
 MicrosoftStickyNotes_8wekyb3d8bbwe
 People_8wekyb3d8bbwe
 PowerAutomateDesktop_8wekyb3d8bbwe
 Todos_8wekyb3d8bbwe
 Windows.Photos_8wekyb3d8bbwe
 WindowsAlarms_8wekyb3d8bbwe
 WindowsCalculator_8wekyb3d8bbwe
 WindowsCamera_8wekyb3d8bbwe
 WindowsFeedbackHub_8wekyb3d8bbwe
 WindowsMaps_8wekyb3d8bbwe
 Xbox.TCUI_8wekyb3d8bbwe
 XboxGameOverlay_8wekyb3d8bbwe
 XboxGamingOverlay_8wekyb3d8bbwe
 XboxIdentityProvider_8wekyb3d8bbwe
 XboxSpeechToTextOverlay_8wekyb3d8bbwe
 YourPhone_8wekyb3d8bbwe
 #############################################################
Run the script as Administrator and follow the instructions on screen.

Latest download: https://github.com/speediegamer/elevendebloater